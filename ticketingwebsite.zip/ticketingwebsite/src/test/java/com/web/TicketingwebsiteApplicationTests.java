package com.web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TicketingwebsiteApplicationTests {

	@Test
	void contextLoads() {
	}

}
