package com.web.exceptions;

public class TicketNotFoundException extends Exception {
	public TicketNotFoundException(String message) {
		super(message);
	}

}
