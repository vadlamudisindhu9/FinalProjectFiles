package com.web.controler;



import org.slf4j.*;
import java.util.List;

import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.web.exceptions.TicketNotFoundException;
import com.web.model.PreviousOrders;
import com.web.model.Tickets;
import com.web.model.UserDetailss;
import com.web.repository.PreviousOrdersRepository;
import com.web.service.ITicketService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class TicketController {
	private static final Logger logger = LoggerFactory.getLogger(TicketController.class);
	@Autowired
	private ITicketService iTicketService;
	@Autowired
	private PreviousOrdersRepository previousOrderRepository;
	@GetMapping("/sell")
	public String viewSellPage(Model model,HttpSession session,HttpServletRequest req) {
		session = req.getSession(false);
		if(session==null || session.getAttribute("userid")==null) {
			return "redirect:/login?expired=true";
		}
		UserDetailss use = (UserDetailss) session.getAttribute("userid");
		String name = use.getUserName();
		List<Tickets> ticket = iTicketService.getAll(((UserDetailss)session.getAttribute("userid")).getUserId());
		
		if(ticket.isEmpty()) {
			logger.warn("no tickets to display "+name);
			model.addAttribute("empty","You haven't created any tickets to display please create one");
		}
		model.addAttribute("listTicket", ticket);
		return "index";		
	}
	@GetMapping("/buy")
	public String viewBuyPage(Model model,HttpSession session,HttpServletRequest req) {
		session = req.getSession(false);
		if(session==null || session.getAttribute("userid")==null) {
			return "redirect:/login?expired=true";
		}
		model.addAttribute("listTicket", iTicketService.getList());
		return "buyTickets";
	}
	@GetMapping("/showNewTicketForm")
	public String showNewTicketEntryForm(Model model,HttpSession session) {
		Tickets ticket = new Tickets();
		ticket.setUser(((UserDetailss)session.getAttribute("userid")));
		model.addAttribute("ticket", ticket);
		return "createTicket";
	}
	@GetMapping("/purchasing/{TicketId}")
	public String viewPurchasing(@PathVariable (value="TicketId") int TicketId,Model model) throws TicketNotFoundException {
		Tickets ticket = iTicketService.getTicketById(TicketId);
		if(ticket== null) {
			throw new TicketNotFoundException("The ticket Id "+TicketId+" is not available please search with another Id");
		}
		model.addAttribute("ticket", ticket);
		return "purchasingTicket";
		
	}
	@PostMapping("/saveBuy")
	public String saveBuy(@ModelAttribute("buyyticket") Tickets ticket,@RequestParam("quantity") int quant,HttpSession session) {
		int finalValue = ticket.getTicketsAvailable()-quant;
		ticket.setTicketsAvailable(finalValue);
		iTicketService.saveTicket(ticket);
		PreviousOrders order = new PreviousOrders();
		order.setTickets(ticket);
		order.setSoldStatus(true);
		order.setQuantity(quant);
		order.setUser(((UserDetailss)session.getAttribute("userid")));
		previousOrderRepository.save(order);
		return"payment";
			
	}                        
//	@GetMapping("/purchase")
//	public String purchaseTicket() {
//		return "payment";
//	}
	@GetMapping("/success")
	public String successs() {
		return "success";
	}
	@PostMapping("/saveTicket")
	public String saveTicket(@ModelAttribute("ticket")Tickets ticket) {
		iTicketService.saveTicket(ticket);
		return "redirect:/sell";
	}
	@GetMapping("/showFormForUpdate/{TicketId}")
	public String showFormForUpdate(@PathVariable ( value = "TicketId") int TicketId, Model model,HttpSession session) throws TicketNotFoundException {
		
		Tickets ticket = iTicketService.getTicketById(TicketId);
		if(ticket== null) {
			throw new TicketNotFoundException("The ticket Id "+TicketId+" is not available please search with another Id");
		}
		ticket.setUser(((UserDetailss)session.getAttribute("userid")));
		model.addAttribute("ticket", ticket);
		return "updateTickets";
	}
	
	@GetMapping("/deleteTicket/{TicketId}")
	public String deleteEmployee(@PathVariable (value = "TicketId") int TicketId) {
		
		iTicketService.deleteTicketById(TicketId);
		return "redirect:/sell";
	}
	
	
	
}
