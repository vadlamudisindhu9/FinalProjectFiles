package com.web.controler;



import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.web.model.UserDetailss;
import com.web.repository.UserRepository;
import com.web.service.IUserService;

import jakarta.servlet.http.HttpSession;

@Controller
public class UserController {
	@Autowired
	private IUserService iUserService;
	@Autowired 
	private UserRepository userRepository;
	public UserController(IUserService iUserService) {
		super();
		this.iUserService = iUserService;
	}
	@RequestMapping("/")
	public String showHome() {
		return "Home";
	}
	@GetMapping("/main")
	public String main(Model model) {
		
		return "main";
	}
	@GetMapping("/login")
	public String login(@RequestParam(required=false) boolean expired,  Model model,UserDetailss user) {
		if(expired) {
			model.addAttribute("expiredMessage", "Session ended please login again");
		}
		model.addAttribute("user", user);
		return "login";
	}
	@PostMapping("/login")
	public String loginSave(@ModelAttribute("user") UserDetailss user,Model model,HttpSession session){
		UserDetailss users = iUserService.findByEmailAndPassword(user.getEmail(),user.getPassword());
		session.setAttribute("userid", users);
		
		if(users!=null) {
			model.addAttribute("wel", users.getUserName());
			return "main";
		}
		return "redirect:/login?error";
	}
	
	@GetMapping("/registration")
	public String showRegistrationForm(Model model,UserDetailss user) {
		model.addAttribute("user", user);
		return "registration";
	}
	@PostMapping("/registration")
	public String registerUserAccount(@ModelAttribute("user")UserDetailss user,Model model) {
		UserDetailss users = iUserService.findByEmail(user.getEmail());
		if(users!=null) {
			model.addAttribute("present", users);
			return "registration";
		}
		iUserService.save(user);
		return "redirect:/registration?success";
	}
	@GetMapping("/logout")
	public String logout() {
		return "redirect:/";
	}
	@GetMapping("/contact")
	public String contact() {
		return "contact";
	}
	@GetMapping("/reply")
	public String reply() {
		return "reply";
	}

}
