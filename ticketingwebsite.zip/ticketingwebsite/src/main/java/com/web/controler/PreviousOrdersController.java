package com.web.controler;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.web.model.PreviousOrders;
import com.web.model.UserDetailss;
import com.web.service.IPreviousOrderService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

@Controller
public class PreviousOrdersController {
	private static final Logger logger = LoggerFactory.getLogger(TicketController.class);
	@Autowired
	private IPreviousOrderService iorderservice;
	
	@GetMapping("/previousOrders")
	public String previousOrders(Model model,HttpSession session,HttpServletRequest req) {
		session = req.getSession(false);
		if(session==null || session.getAttribute("userid")==null) {
			return "redirect:/login?expired=true";
		}
		UserDetailss use = (UserDetailss) session.getAttribute("userid");
		String name = use.getUserName();
		List<PreviousOrders> previousorders = iorderservice.getById(((UserDetailss)session.getAttribute("userid")).getUserId());
		
		if(previousorders.isEmpty()) {
			logger.warn("no orders to display "+name);
			model.addAttribute("emptyorder","you haven't purchased any tickets to show here");
		}
		model.addAttribute("listorders",previousorders);
		return "previousOrder";
		
	}

}
