package com.web.service;

import java.util.List;



import com.web.model.Tickets;

public interface ITicketService {
	List<Tickets> getAllTickets();
	void saveTicket(Tickets ticket);
	Tickets getTicketById(int TicketId);
	void deleteTicketById(int TicketId);
	
	List<Tickets> getAll(int userId);
	List<Tickets> getList();

}
