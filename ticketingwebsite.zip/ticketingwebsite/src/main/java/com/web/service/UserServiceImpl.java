package com.web.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import com.web.model.UserDetailss;
import com.web.repository.UserRepository;


@Service
public class UserServiceImpl implements IUserService{
	private static final Logger logger = LoggerFactory.getLogger(ITicketService.class);
	@Autowired
	private UserRepository userRepository;
	
	public UserServiceImpl(UserRepository userRepository) {
		super();
		this.userRepository = userRepository;
	}

	@Override
	public UserDetailss save(UserDetailss user) {
		// TODO Auto-generated method stub
		UserDetailss users = userRepository.save(user);
		if(users == null) {
			logger.warn("not saved");
		}
		else {
			logger.info("saved successfully");
		}
		return users;
	}

	@Override
	public UserDetailss findByEmail(String email) {
		// TODO Auto-generated method stub
		UserDetailss users = userRepository.findByEmail(email);
		if(users==null) {
			logger.warn("email not found");
		}
		else {
			logger.info("email match found");
		}
		return users;
	}

	@Override
	public UserDetailss findByEmailAndPassword(String email, String password) {
		// TODO Auto-generated method stub
		UserDetailss users = userRepository.findByEmailAndPassword(email, password);
		if(users==null) {
			logger.warn("email and password not found");
		}
		else {
			logger.info("email and password match found for user: "+users.getUserName());
		}
		return users;
		
	}

	
	

	

	

	
	
	
	

	

	
}