package com.web.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.stereotype.Service;


import com.web.model.Tickets;
import com.web.repository.TicketsRepository;
@Service
public class TicketServiceImpl implements ITicketService {
	private static final Logger logger = LoggerFactory.getLogger(ITicketService.class);
	@Autowired
	private TicketsRepository ticketRepository;

	@Override
	public List<Tickets> getAllTickets() {
		// TODO Auto-generated method stub
		List<Tickets> tick = ticketRepository.findAll();
		if(tick==null) {
			logger.warn("tickets list is empty");
		}
		else {
			logger.info("tickets list fetched successfully");
		}
		return tick;
	}

	@Override
	public void saveTicket(Tickets ticket) {
		// TODO Auto-generated method stub
		this.ticketRepository.save(ticket);
		
	}

	@Override
	public Tickets getTicketById(int TicketId) {
		// TODO Auto-generated method stub
//		Optional<Tickets> optional = ticketRepository.findById(TicketId);
//		Tickets ticket = null;
//		if (optional.isPresent()) {
//			ticket = optional.get();
//		} else {
//			throw new RuntimeException(" Ticket not found for id :: " + TicketId);
//		}
		Tickets tickets = ticketRepository.findByTicketId(TicketId);
		if(tickets==null) {
			logger.warn("this ticket id "+TicketId+" is not found");
		}
		else {
			logger.info("the ticket id is fetched");
		}
		return tickets;
	}

	@Override
	public void deleteTicketById(int TicketId) {
		// TODO Auto-generated method stub
		this.ticketRepository.deleteById(TicketId);
		
	}


	@Override
	public List<Tickets> getAll(int userId) {
		// TODO Auto-generated method stub
		List<Tickets> ticket = ticketRepository.getAll(userId);
		if(ticket.isEmpty()) {
			logger.warn("tickets list is empty");
		}
		else {
			logger.info("tickets list fetched successfully");
		}
		return ticket;
	}

	@Override
	public List<Tickets> getList() {
		// TODO Auto-generated method stub
		List<Tickets> ticket = ticketRepository.getEle();
		if(ticket.isEmpty()) {
			logger.warn("tickets list is empty");
		}
		else {
			logger.info("tickets list fetched successfully");
		}
		return ticket;
		
	}

}
