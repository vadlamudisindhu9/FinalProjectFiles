package com.web.service;

import java.util.List;

import com.web.model.PreviousOrders;

public interface IPreviousOrderService {
	List<PreviousOrders> getById(int id);

}
