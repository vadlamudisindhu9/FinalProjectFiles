package com.web.service;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.web.model.PreviousOrders;
import com.web.model.Tickets;
import com.web.repository.PreviousOrdersRepository;
@Service
public class PreviousOrdersServiceImpl implements IPreviousOrderService {
	private static final Logger logger = LoggerFactory.getLogger(ITicketService.class);
	@Autowired
	private PreviousOrdersRepository previousOrderRepository;

	@Override
	public List<PreviousOrders> getById(int id) {
		// TODO Auto-generated method stub
		List<PreviousOrders> order = previousOrderRepository.getAll(id);
		if(order.isEmpty()) {
			logger.warn("order list is empty");
		}
		else {
			logger.info("order list fetched successfully");
		}
		return order;
	}

}
