package com.web.service;


//import org.springframework.security.core.userdetails.UserDetails;
import com.web.model.UserDetailss;

public interface IUserService {
	UserDetailss save(UserDetailss user);
	UserDetailss findByEmail(String email);
	UserDetailss findByEmailAndPassword(String email,String password);
	
}
