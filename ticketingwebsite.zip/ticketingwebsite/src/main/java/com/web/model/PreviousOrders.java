package com.web.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;

@Entity

public class PreviousOrders {
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int orderId;
	@ManyToOne
	@JoinColumn(name="ticket_id")
	private Tickets tickets;
	@ManyToOne
	@JoinColumn(name="user_id")
	private UserDetailss user;
	private int quantity;
	private boolean soldStatus;
	public PreviousOrders(int orderId, Tickets tickets, UserDetailss user, int quantity, boolean soldStatus) {
		super();
		this.orderId = orderId;
		this.tickets = tickets;
		this.user = user;
		this.quantity = quantity;
		this.soldStatus = soldStatus;
	}
	public PreviousOrders() {
		super();
	}
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	public Tickets getTickets() {
		return tickets;
	}
	public void setTickets(Tickets tickets) {
		this.tickets = tickets;
	}
	public UserDetailss getUser() {
		return user;
	}
	public void setUser(UserDetailss user) {
		this.user = user;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public boolean isSoldStatus() {
		return soldStatus;
	}
	public void setSoldStatus(boolean soldStatus) {
		this.soldStatus = soldStatus;
	}
	@Override
	public String toString() {
		return "PreviousOrders [orderId=" + orderId + ", tickets=" + tickets + ", user=" + user + ", quantity="
				+ quantity + ", soldStatus=" + soldStatus + "]";
	}
	
}
