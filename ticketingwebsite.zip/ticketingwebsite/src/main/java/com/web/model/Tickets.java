package com.web.model;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;


@Entity
public class Tickets {
	@Override
	public String toString() {
		return "Tickets [ticketId=" + ticketId  + ", eventName=" + eventName
				+ ", description=" + description + ", ticketsAvailable=" + ticketsAvailable + ", user=" + user
				+ ", price=" + price + "]";
	}
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	private int ticketId;
	private String eventName;
	private String description;
	private int ticketsAvailable;
	@ManyToOne
	@JoinColumn(name="user_id")
	
	private UserDetailss user;
	private int price;
	public Tickets(int ticketId, String eventName, String description,
			int ticketsAvailable, UserDetailss user, int price) {
		super();
		this.ticketId = ticketId;
		
		this.eventName = eventName;
		this.description = description;
		this.ticketsAvailable = ticketsAvailable;
		this.user = user;
		this.price = price;
	}
	public Tickets() {
		super();
	}
	public int getTicketId() {
		return ticketId;
	}
	public void setTicketId(int ticketId) {
		this.ticketId = ticketId;
	}
	
	public String getEventName() {
		return eventName;
	}
	public void setEventName(String eventName) {
		this.eventName = eventName;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getTicketsAvailable() {
		return ticketsAvailable;
	}
	public void setTicketsAvailable(int ticketsAvailable) {
		this.ticketsAvailable = ticketsAvailable;
	}
	public UserDetailss getUser() {
		return user;
	}
	public void setUser(UserDetailss user) {
		this.user = user;
	}
	public int getPrice() {
		return price;
	}
	public void setPrice(int price) {
		this.price = price;
	}
	
}
