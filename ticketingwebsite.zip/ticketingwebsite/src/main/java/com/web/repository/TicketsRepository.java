package com.web.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.web.model.Tickets;
@Repository
public interface TicketsRepository extends JpaRepository<Tickets, Integer>{
	Tickets  findByTicketId(int ticketId);
	@Query(value="select * from Tickets  where user_id = ? and tickets_available>0",nativeQuery=true)
	List<Tickets> getAll(int userId);
	@Query(value="select * from Tickets where tickets_available>0",nativeQuery=true)
	List<Tickets> getEle();
}
