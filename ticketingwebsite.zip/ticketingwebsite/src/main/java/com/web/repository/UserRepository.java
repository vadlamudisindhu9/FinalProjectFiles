package com.web.repository;






import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;


import com.web.model.UserDetailss;

@Repository
public interface UserRepository extends JpaRepository<UserDetailss, Integer> {

	UserDetailss findByEmail(String email);
	UserDetailss findByEmailAndPassword(String email,String password);
	
	

}
