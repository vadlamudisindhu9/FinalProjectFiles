package com.web.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.web.model.PreviousOrders;

@Repository
public interface PreviousOrdersRepository extends JpaRepository<PreviousOrders, Integer> {
	@Query(value="select * from previous_orders where user_id=?",nativeQuery=true)
	List<PreviousOrders> getAll(int userId);
	

}
